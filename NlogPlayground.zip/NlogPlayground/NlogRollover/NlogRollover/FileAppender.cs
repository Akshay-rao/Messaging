﻿namespace NlogRollover;

public interface IAppender
{
    Task AppendAsync(string message);
}
public class FileAppender : IAppender
{
    private const string FilePath = "c:/development/file.txt";
    private readonly IFileArchiverStrategy _fileArchiverStrategy;
    private readonly SemaphoreSlim _semaphore = new(1, 1);
    public FileAppender(IFileArchiverStrategy fileArchiverStrategy)
    {
        _fileArchiverStrategy = fileArchiverStrategy;
    }

    public async Task AppendAsync(string message)
    {
        await _semaphore.WaitAsync().ConfigureAwait(false);
        try
        {
            await _fileArchiverStrategy.ArchiveFileAsync(FilePath).ConfigureAwait(false);
            await using var writer = File.AppendText(FilePath);
            await writer.WriteLineAsync(message).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        finally
        {
            _semaphore.Release();
        }
    }
}