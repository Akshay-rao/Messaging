﻿using System.Diagnostics;
using Microsoft.Extensions.DependencyInjection;

namespace NlogRollover
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            const string message = "This is a new message.";
            var taskList = new List<Task>();
            var serviceProvider = new ServiceCollection()
                .AddSingleton<IFileArchiverStrategy, ArchiveFileStrategy>()
                .AddSingleton<IAppender, FileAppender>()
                .BuildServiceProvider();

            var fileAppender = serviceProvider.GetService<IAppender>();
            if (fileAppender == null)
            {
                Console.WriteLine("File appender not found.");
                return;
            }

            
            for (int i = 0; i < 1000000; i++)
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();

                await fileAppender.AppendAsync(message);

                stopwatch.Stop();
                
                Console.WriteLine("Time taken: " + stopwatch.Elapsed);
            }
            
            Console.WriteLine("Message appended to file.");
        }
    }
}
