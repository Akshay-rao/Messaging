﻿namespace NlogRollover;
public interface IFileArchiverStrategy
{
    Task ArchiveFileAsync(string filePath);
}

public class NoArchiveFileStrategy : IFileArchiverStrategy
{
    public Task ArchiveFileAsync(string filePath)
    {
        return Task.CompletedTask;
    }
}
public class ArchiveFileStrategy : IFileArchiverStrategy
{
    public Task ArchiveFileAsync(string filePath)
    {
        var fileCreationTime = GetCreationTime(filePath);
        var currentTime = DateTime.Now;

        if (fileCreationTime.HasValue && !((currentTime - fileCreationTime.Value).TotalMinutes >= 2))
            return Task.CompletedTask;
        MoveFile(filePath);
        return Task.CompletedTask;
    }

    private DateTime? GetCreationTime(string filePath)
    {
        if (!File.Exists(filePath))
            return null;
        return File.GetCreationTime(filePath);
    }

    private void MoveFile(string filePath)
    {
        if (!File.Exists(filePath))
            return;
        var archiveFileName = GetArchiveFileName(filePath);
        var archiveFilePath = GetArchiveFilePath(filePath, archiveFileName);
        File.Move(filePath, archiveFilePath);
        File.Delete(filePath);
        File.Create(filePath).Dispose();
        File.SetCreationTime(filePath, DateTime.Now);
    }

    private string GetArchiveFileName(string filePath)
    {
        var fileCreationTime = GetCreationTime(filePath);
        return $"{Path.GetFileNameWithoutExtension(filePath)}_{fileCreationTime:yyyy-MM-dd-HH-mm-ss}{Path.GetExtension(filePath)}";
    }

    private string GetArchiveFilePath(string filePath, string archiveFileName)
    {
        return Path.Combine(Path.GetDirectoryName(filePath) ?? string.Empty, archiveFileName);
    }
}